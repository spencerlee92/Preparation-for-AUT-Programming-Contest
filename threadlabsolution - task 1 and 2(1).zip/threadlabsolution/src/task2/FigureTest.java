package task2;

public class FigureTest{

    public static void main(String args[]){

        Figure fig=new Figure();
        Space sp=new Space(fig);
        Star st=new Star(fig);
        Thread spaceThread = new Thread(sp, "Space");
        spaceThread.start();

        Thread starThread = new Thread(st, "Star");
        starThread.start();
    }

}

package task2;

class Star implements Runnable{
    Figure fig;
    
    //constructor
    Star(Figure star){
        this.fig = star;

    }
    
    //override
    public void run(){
        for(int i=1;i<=9;i++)
            fig.printStar(i);
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

/**
 *
 * @author qbai
 */
public class CounterRun implements Runnable{
    public int num;
    public CounterRun(int j){
        this.num=j;
    }
    

    public static void main(String[] args){
    
        CounterRun odd=new CounterRun(1);
        CounterRun even=new CounterRun(2);
        Thread t1=new Thread(odd);
        Thread t2=new Thread(even);
        t1.start();
        t2.start();
    }

    public void run(){
         for(int i=this.num; i<=10; i+=2)
         {
             System.out.print(i + " ");
             try{
                 Thread.sleep(1000);
             } catch (InterruptedException e){
                          System.err.println(e);}
	     }
        }
    }

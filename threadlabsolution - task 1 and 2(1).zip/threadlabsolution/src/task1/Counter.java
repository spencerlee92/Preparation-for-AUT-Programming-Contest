package task1;

public class Counter extends Thread{
    int num;

    public static void main(String[] args){
      Counter t1=new Counter(1);
      Counter t2=new Counter(2);
      t1.start();
      t2.start();
    }

    public Counter(int i){
        this.num=i;
    }

    public void run(){
         for(int j=this.num; j<=10; j+=2)
         {
             System.out.print(j + " ");
             try{
                 Thread.sleep(1000);
             } catch (InterruptedException e){
                          System.err.println(e);}
	     }
        }
    }
